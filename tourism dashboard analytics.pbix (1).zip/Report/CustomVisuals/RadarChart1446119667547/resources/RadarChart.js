/*
 *  Power BI Visualizations
 *
 *  Copyright (c) Microsoft Corporation
 *  All rights reserved.
 *  MIT License
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the ""Software""), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 *  THE SOFTWARE.
 */
var powerbi;
(function (powerbi) {
    var visuals;
    (function (visuals) {
        var RadarChart1446119667547;
        (function (RadarChart1446119667547) {
            var SelectionManager = visuals.utility.SelectionManager;
            var CreateClassAndSelector = jsCommon.CssConstants.createClassAndSelector;
            var PixelConverter = jsCommon.PixelConverter;
            /**
             * RadarChartBehavior
             */
            var RadarChartWebBehavior = (function () {
                function RadarChartWebBehavior() {
                }
                RadarChartWebBehavior.prototype.bindEvents = function (options, selectionHandler) {
                    var selection = this.selection = options.selection;
                    var clearCatcher = options.clearCatcher;
                    selection.on('click', function (d) {
                        selectionHandler.handleSelection(d, d3.event.ctrlKey);
                        d3.event.stopPropagation();
                    });
                    clearCatcher.on('click', function () {
                        selectionHandler.handleClearSelection();
                    });
                };
                RadarChartWebBehavior.prototype.renderSelection = function (hasSelection) {
                    this.selection.style("opacity", function (d) { return (hasSelection && !d.selected) ? RadarChart.DimmedAreaFillOpacity : RadarChart.AreaFillOpacity; });
                };
                return RadarChartWebBehavior;
            }());
            RadarChart1446119667547.RadarChartWebBehavior = RadarChartWebBehavior;
            var RadarChart = (function () {
                function RadarChart(options) {
                    if (options) {
                        if (options.svg)
                            this.svg = options.svg;
                        if (options.animator)
                            this.animator = options.animator;
                        if (options.margin)
                            this.margin = options.margin;
                    }
                }
                RadarChart.converter = function (dataView, colors) {
                    if (!dataView ||
                        !dataView.categorical ||
                        !dataView.categorical.categories ||
                        !(dataView.categorical.categories.length > 0) ||
                        !dataView.categorical.categories[0] ||
                        !dataView.categorical.values ||
                        !(dataView.categorical.values.length > 0)) {
                        return {
                            legendData: {
                                dataPoints: []
                            },
                            settings: {
                                showLegend: true
                            },
                            series: [],
                            dataLabelsSettings: visuals.dataLabelUtils.getDefaultPointLabelSettings(),
                        };
                    }
                    var catDv = dataView.categorical;
                    var values = catDv.values;
                    var series = [];
                    var colorHelper = new visuals.ColorHelper(colors, RadarChart.Properties.dataPoint.fill);
                    var legendData = {
                        fontSize: 8.25,
                        dataPoints: [],
                        title: ""
                    };
                    //Parse legend settings          
                    var legendSettings = RadarChart.parseSettings(dataView);
                    var dataLabelsSettings = RadarChart.parseLabelSettings(dataView);
                    for (var i = 0, iLen = values.length; i < iLen; i++) {
                        var color = colors.getColorByIndex(i).value, serieIdentity = void 0, queryName = void 0, displayName = void 0, dataPoints = [];
                        if (values[i].source) {
                            var source = values[i].source;
                            if (source.queryName) {
                                queryName = source.queryName;
                                serieIdentity = visuals.SelectionId.createWithMeasure(queryName);
                            }
                            if (source.displayName)
                                displayName = source.displayName;
                            if (source.objects) {
                                var objects = source.objects;
                                color = colorHelper.getColorForMeasure(objects, queryName);
                            }
                        }
                        legendData.dataPoints.push({
                            label: displayName,
                            color: color,
                            icon: visuals.LegendIcon.Box,
                            selected: false,
                            identity: serieIdentity
                        });
                        for (var k = 0, kLen = values[i].values.length; k < kLen; k++) {
                            var dataPointIdentity = visuals.SelectionIdBuilder
                                .builder()
                                .withMeasure(queryName)
                                .withCategory(catDv.categories[0], k)
                                .withSeries(dataView.categorical.values, dataView.categorical.values[i])
                                .createSelectionId();
                            var tooltipInfo = visuals.TooltipBuilder.createTooltipInfo(RadarChart.formatStringProp, catDv, catDv.categories[0].values[k], values[i].values[k], null, null, i);
                            var labelFormatString = visuals.valueFormatter.getFormatString(catDv.values[i].source, RadarChart.formatStringProp);
                            var fontSizeInPx = jsCommon.PixelConverter.fromPoint(dataLabelsSettings.fontSize);
                            dataPoints.push({
                                x: k,
                                y: values[i].values[k],
                                color: color,
                                identity: dataPointIdentity,
                                selected: false,
                                tooltipInfo: tooltipInfo,
                                value: values[i].values[k],
                                labelFormatString: labelFormatString,
                                labelFontSize: fontSizeInPx,
                            });
                        }
                        if (dataPoints.length > 0)
                            series.push({
                                fill: color,
                                name: displayName,
                                data: dataPoints,
                                identity: serieIdentity,
                            });
                    }
                    return {
                        legendData: legendData,
                        settings: legendSettings,
                        series: series,
                        dataLabelsSettings: dataLabelsSettings,
                    };
                };
                RadarChart.prototype.init = function (options) {
                    var element = options.element;
                    this.selectionManager = new SelectionManager({ hostServices: options.host });
                    if (!this.svg) {
                        this.svg = d3.select(element.get(0)).append('svg');
                        this.svg.style('position', 'absolute');
                    }
                    if (!this.margin)
                        this.margin = RadarChart.DefaultMargin;
                    this.svg.classed(RadarChart.VisualClassName, true);
                    this.interactivityService = visuals.createInteractivityService(options.host);
                    this.isInteractiveChart = options.interactivity && options.interactivity.isInteractiveLegend;
                    this.legend = visuals.createLegend(element, this.isInteractiveChart, this.interactivityService, true, visuals.LegendPosition.Top);
                    this.colors = options.style.colorPalette.dataColors;
                    this.mainGroupElement = this.svg.append('g');
                    this.segments = this.mainGroupElement
                        .append('g')
                        .classed(RadarChart.Segments.class, true);
                    this.axis = this.mainGroupElement
                        .append('g')
                        .classed(RadarChart.Axis.class, true);
                    this.chart = this.mainGroupElement
                        .append('g')
                        .classed(RadarChart.Chart.class, true);
                };
                RadarChart.prototype.update = function (options) {
                    if (!options.dataViews || !options.dataViews[0])
                        return;
                    var dataView = options.dataViews[0];
                    this.radarChartData = RadarChart.converter(dataView, this.colors);
                    var categories = [], series = this.radarChartData.series, dataViewMetadataColumn, duration = visuals.AnimatorCommon.GetAnimationDuration(this.animator, options.suppressAnimations);
                    if (dataView.categorical &&
                        dataView.categorical.categories &&
                        dataView.categorical.categories[0] &&
                        dataView.categorical.categories[0].values)
                        categories = dataView.categorical.categories[0].values;
                    if (dataView.metadata && dataView.metadata.columns && dataView.metadata.columns.length > 0)
                        dataViewMetadataColumn = dataView.metadata.columns[0];
                    this.viewport = {
                        height: options.viewport.height > 0 ? options.viewport.height : 0,
                        width: options.viewport.width > 0 ? options.viewport.width : 0
                    };
                    this.parseLegendProperties(dataView);
                    this.renderLegend(this.radarChartData);
                    this.updateViewport();
                    this.svg
                        .attr({
                        'height': this.viewport.height,
                        'width': this.viewport.width
                    });
                    var mainGroup = this.mainGroupElement;
                    mainGroup.attr('transform', visuals.SVGUtil.translate(this.viewport.width / 2, this.viewport.height / 2));
                    var width = this.viewport.width - this.margin.left - this.margin.right;
                    var height = this.viewport.height - this.margin.top - this.margin.bottom;
                    this.angle = RadarChart.Radians / categories.length;
                    this.radius = RadarChart.SegmentFactor * RadarChart.Scale * Math.min(width, height) / 2;
                    this.drawCircularSegments(categories);
                    this.drawAxes(categories);
                    this.drawAxesLabels(categories, dataViewMetadataColumn);
                    this.drawChart(series, duration);
                    this.drawDataLabels(series);
                };
                RadarChart.prototype.getRadarChartLabelLayout = function (labelSettings, allDataPoints) {
                    var formattersCache = visuals.dataLabelUtils.createColumnFormatterCacheManager();
                    var angle = this.angle;
                    var radius = this.radius;
                    var dataPoints = this.getDataPoints(this.radarChartData.series);
                    var stack = d3.layout.stack();
                    var layers = stack(dataPoints);
                    var viewport = this.viewport;
                    var halfHeight = this.viewport.height / 2;
                    var halfWidth = this.viewport.width / 2;
                    var y = d3.scale.linear()
                        .domain([0, d3.max(layers, function (layer) {
                            return d3.max(layer, function (d) {
                                return d.y0 + d.y;
                            });
                        })]).range([0, radius]);
                    return {
                        labelText: function (d) {
                            var formmater = formattersCache.getOrCreate(d.labelFormatString, labelSettings);
                            if (labelSettings.displayUnits === 0) {
                                var maxDataPoint = _.max(allDataPoints, function (d) { return d.value; });
                                var maxValue = maxDataPoint.value > 0 ? maxDataPoint.value : 0;
                                formmater = formattersCache.getOrCreate(d.labelFormatString, labelSettings, maxValue);
                            }
                            return visuals.dataLabelUtils.getLabelFormattedText({ label: formmater.format(d.value), maxWidth: viewport.width, fontSize: labelSettings.fontSize });
                        },
                        labelLayout: {
                            x: function (d) { return -1 * y(d.y) * Math.sin(d.x * angle) + halfWidth; },
                            y: function (d) { return -1 * y(d.y) * Math.cos(d.x * angle) + halfHeight - 10; },
                        },
                        filter: function (d) {
                            return (d != null && d.value != null);
                        },
                        style: {
                            'fill': labelSettings.labelColor,
                            'font-size': function (d) { return PixelConverter.fromPoint(labelSettings.fontSize); },
                        },
                    };
                };
                RadarChart.prototype.drawCircularSegments = function (values) {
                    var data = [];
                    var angle = this.angle, factor = RadarChart.SegmentFactor, levels = RadarChart.SegmentLevels, radius = this.radius;
                    for (var level = 0; level < levels - 1; level++) {
                        var levelFactor = radius * ((level + 1) / levels);
                        var transform = -1 * levelFactor;
                        for (var i = 0; i < values.length; i++)
                            data.push({
                                x1: levelFactor * (1 - factor * Math.sin(i * angle)),
                                y1: levelFactor * (1 - factor * Math.cos(i * angle)),
                                x2: levelFactor * (1 - factor * Math.sin((i + 1) * angle)),
                                y2: levelFactor * (1 - factor * Math.cos((i + 1) * angle)),
                                translate: visuals.SVGUtil.translate(transform, transform)
                            });
                    }
                    var selection = this.mainGroupElement
                        .select(RadarChart.Segments.selector)
                        .selectAll(RadarChart.SegmentNode.selector)
                        .data(data);
                    selection
                        .enter()
                        .append('svg:line')
                        .classed(RadarChart.SegmentNode.class, true);
                    selection
                        .attr({
                        'x1': function (item) { return item.x1; },
                        'y1': function (item) { return item.y1; },
                        'x2': function (item) { return item.x2; },
                        'y2': function (item) { return item.y2; },
                        'transform': function (item) { return item.translate; }
                    });
                    selection.exit().remove();
                };
                RadarChart.prototype.drawDataLabels = function (series) {
                    var allDataPoints = this.getAllDataPointsList(series);
                    if (this.radarChartData.dataLabelsSettings.show) {
                        var layout = this.getRadarChartLabelLayout(this.radarChartData.dataLabelsSettings, allDataPoints);
                        var viewport = this.viewport;
                        var labels = visuals.dataLabelUtils.drawDefaultLabelsForDataPointChart(allDataPoints, this.mainGroupElement, layout, viewport);
                        if (labels)
                            labels.attr('transform', visuals.SVGUtil.translate(-(viewport.width / 2), -(viewport.height / 2)));
                    }
                    else
                        visuals.dataLabelUtils.cleanDataLabels(this.mainGroupElement);
                };
                RadarChart.prototype.drawAxes = function (values) {
                    var angle = this.angle, radius = -1 * this.radius;
                    var selection = this.mainGroupElement
                        .select(RadarChart.Axis.selector)
                        .selectAll(RadarChart.AxisNode.selector);
                    var axis = selection.data(values);
                    axis
                        .enter()
                        .append('svg:line');
                    axis
                        .attr({
                        'x1': 0,
                        'y1': 0,
                        'x2': function (name, i) { return radius * Math.sin(i * angle); },
                        'y2': function (name, i) { return radius * Math.cos(i * angle); }
                    })
                        .classed(RadarChart.AxisNode.class, true);
                    axis.exit().remove();
                };
                RadarChart.prototype.drawAxesLabels = function (values, dataViewMetadataColumn) {
                    var angle = this.angle, radius = -1 * this.radius, length = values.length;
                    var formatter = visuals.valueFormatter.create({
                        format: visuals.valueFormatter.getFormatString(dataViewMetadataColumn, RadarChart.formatStringProp, true),
                        value: values[0],
                        value2: values[length - 1],
                    });
                    var selection = this.mainGroupElement
                        .select(RadarChart.Axis.selector)
                        .selectAll(RadarChart.AxisLabel.selector);
                    var labels = selection.data(values);
                    labels
                        .enter()
                        .append('svg:text');
                    labels
                        .attr({
                        'text-anchor': 'middle',
                        'dy': '1.5em',
                        'transform': visuals.SVGUtil.translate(0, -10),
                        'x': function (name, i) { return (radius - 20) * Math.sin(i * angle); },
                        'y': function (name, i) { return (radius - 10) * Math.cos(i * angle); }
                    })
                        .text(function (item) { return formatter.format(item); })
                        .classed(RadarChart.AxisLabel.class, true);
                    labels.exit().remove();
                };
                RadarChart.prototype.drawChart = function (series, duration) {
                    var angle = this.angle, radius = this.radius, dotRadius = 5, dataPoints = this.getDataPoints(series);
                    var stack = d3.layout.stack();
                    var layers = stack(dataPoints);
                    var y = d3.scale.linear()
                        .domain([0, d3.max(layers, function (layer) {
                            return d3.max(layer, function (d) {
                                return d.y0 + d.y;
                            });
                        })]).range([0, radius]);
                    var calculatePoints = function (points) {
                        return points.map(function (value) {
                            var x1 = -1 * y(value.y) * Math.sin(value.x * angle);
                            var y1 = -1 * y(value.y) * Math.cos(value.x * angle);
                            return x1 + "," + y1;
                        }).join(' ');
                    };
                    var selection = this.chart.selectAll(RadarChart.ChartNode.selector).data(layers);
                    selection
                        .enter()
                        .append('g')
                        .classed(RadarChart.ChartNode.class, true);
                    var polygon = selection.selectAll(RadarChart.ChartPolygon.selector).data(function (d) {
                        if (d && d.length > 0) {
                            return [d];
                        }
                        return [];
                    });
                    polygon
                        .enter()
                        .append('polygon')
                        .classed(RadarChart.ChartPolygon.class, true);
                    polygon
                        .style('fill', function (d) { return d[0].color; })
                        .style('opacity', RadarChart.DimmedAreaFillOpacity)
                        .on('mouseover', function (d) {
                        d3.select(this).transition()
                            .duration(duration)
                            .style('opacity', RadarChart.AreaFillOpacity);
                    })
                        .on('mouseout', function (d) {
                        d3.select(this).transition()
                            .duration(duration)
                            .style('opacity', RadarChart.DimmedAreaFillOpacity);
                    })
                        .attr('points', calculatePoints);
                    polygon.exit().remove();
                    var dots = selection.selectAll(RadarChart.ChartDot.selector)
                        .data(function (d) { return d.filter(function (d) { return d.y != null; }); });
                    dots.enter()
                        .append('svg:circle')
                        .classed(RadarChart.ChartDot.class, true);
                    dots.attr('r', dotRadius)
                        .attr({
                        'cx': function (value) { return -1 * y(value.y) * Math.sin(value.x * angle); },
                        'cy': function (value) { return -1 * y(value.y) * Math.cos(value.x * angle); }
                    })
                        .style('fill', function (d) { return d.color; });
                    dots.exit().remove();
                    visuals.TooltipManager.addTooltip(dots, function (tooltipEvent) { return tooltipEvent.data.tooltipInfo; }, true);
                    selection.exit().remove();
                    var behaviorOptions = undefined;
                    if (this.interactivityService) {
                        // Register interactivity
                        var dataPointsToBind = this.getAllDataPointsList(series);
                        behaviorOptions = { selection: dots, clearCatcher: this.svg };
                        this.interactivityService.bind(dataPointsToBind, new RadarChartWebBehavior(), behaviorOptions);
                    }
                };
                RadarChart.prototype.renderLegend = function (radarChartData) {
                    if (!radarChartData.legendData)
                        return;
                    var legendData = radarChartData.legendData;
                    if (this.legendObjectProperties) {
                        visuals.LegendData.update(legendData, this.legendObjectProperties);
                        var position = this.legendObjectProperties[visuals.legendProps.position];
                        if (position)
                            this.legend.changeOrientation(visuals.LegendPosition[position]);
                    }
                    else
                        this.legend.changeOrientation(visuals.LegendPosition.Top);
                    var viewport = this.viewport;
                    this.legend.drawLegend(legendData, { height: viewport.height, width: viewport.width });
                    visuals.Legend.positionChartArea(this.svg, this.legend);
                };
                RadarChart.prototype.getDataPoints = function (series) {
                    var dataPoints = [];
                    for (var _i = 0, series_1 = series; _i < series_1.length; _i++) {
                        var serie = series_1[_i];
                        dataPoints.push(serie.data);
                    }
                    return dataPoints;
                };
                RadarChart.prototype.getAllDataPointsList = function (series) {
                    var dataPoints = [];
                    for (var _i = 0, series_2 = series; _i < series_2.length; _i++) {
                        var serie = series_2[_i];
                        dataPoints = dataPoints.concat(serie.data);
                    }
                    return dataPoints;
                };
                RadarChart.prototype.parseLegendProperties = function (dataView) {
                    if (!dataView || !dataView.metadata) {
                        this.legendObjectProperties = {};
                        return;
                    }
                    this.legendObjectProperties = powerbi.DataViewObjects.getObject(dataView.metadata.objects, "legend", {});
                };
                RadarChart.parseSettings = function (dataView) {
                    var objects;
                    if (!dataView || !dataView.metadata || !dataView.metadata.columns || !dataView.metadata.objects)
                        objects = null;
                    else
                        objects = dataView.metadata.objects;
                    return {
                        showLegend: powerbi.DataViewObjects.getValue(objects, RadarChart.Properties.legend.show, true)
                    };
                };
                RadarChart.parseLabelSettings = function (dataView) {
                    var objects;
                    if (!dataView || !dataView.metadata || !dataView.metadata.objects)
                        objects = null;
                    else
                        objects = dataView.metadata.objects;
                    var dataLabelsSettings = visuals.dataLabelUtils.getDefaultPointLabelSettings();
                    var labelsObj = {
                        show: powerbi.DataViewObjects.getValue(objects, RadarChart.Properties.labels.show, dataLabelsSettings.show),
                        labelColor: powerbi.DataViewObjects.getFillColor(objects, RadarChart.Properties.labels.color, dataLabelsSettings.labelColor),
                        displayUnits: powerbi.DataViewObjects.getValue(objects, RadarChart.Properties.labels.displayUnits, dataLabelsSettings.displayUnits),
                        precision: powerbi.DataViewObjects.getValue(objects, RadarChart.Properties.labels.precision, dataLabelsSettings.precision),
                        fontSize: powerbi.DataViewObjects.getValue(objects, RadarChart.Properties.labels.fontSize, dataLabelsSettings.fontSize),
                        position: dataLabelsSettings.position
                    };
                    return labelsObj;
                };
                // This function returns the values to be displayed in the property pane for each object.
                // Usually it is a bind pass of what the property pane gave you, but sometimes you may want to do
                // validation and return other values/defaults
                RadarChart.prototype.enumerateObjectInstances = function (options) {
                    var enumeration = new visuals.ObjectEnumerationBuilder();
                    var settings;
                    if (!this.radarChartData || !this.radarChartData.settings)
                        return [];
                    settings = this.radarChartData.settings;
                    switch (options.objectName) {
                        case "legend":
                            enumeration.pushInstance(this.enumerateLegend(settings));
                            break;
                        case "dataPoint":
                            this.enumerateDataPoint(enumeration);
                            break;
                        case 'labels':
                            this.enumerateDataLabels(enumeration);
                            break;
                    }
                    return enumeration.complete();
                };
                RadarChart.prototype.getLabelSettingsOptions = function (enumeration, labelSettings) {
                    return {
                        enumeration: enumeration,
                        dataLabelsSettings: labelSettings,
                        show: true,
                        displayUnits: true,
                        precision: true,
                        fontSize: true,
                    };
                };
                RadarChart.prototype.enumerateDataLabels = function (enumeration) {
                    var labelSettings = this.radarChartData.dataLabelsSettings;
                    //Draw default settings
                    visuals.dataLabelUtils.enumerateDataLabels(this.getLabelSettingsOptions(enumeration, labelSettings));
                };
                RadarChart.prototype.enumerateLegend = function (settings) {
                    var showTitle = true, titleText = "", legend, labelColor, fontSize = 8;
                    showTitle = powerbi.DataViewObject.getValue(this.legendObjectProperties, visuals.legendProps.showTitle, showTitle);
                    titleText = powerbi.DataViewObject.getValue(this.legendObjectProperties, visuals.legendProps.titleText, titleText);
                    labelColor = powerbi.DataViewObject.getValue(this.legendObjectProperties, visuals.legendProps.labelColor, labelColor);
                    fontSize = powerbi.DataViewObject.getValue(this.legendObjectProperties, visuals.legendProps.fontSize, fontSize);
                    legend = {
                        objectName: "legend",
                        displayName: "legend",
                        selector: null,
                        properties: {
                            show: settings.showLegend,
                            position: visuals.LegendPosition[this.legend.getOrientation()],
                            showTitle: showTitle,
                            titleText: titleText,
                            labelColor: labelColor,
                            fontSize: fontSize,
                        }
                    };
                    return legend;
                };
                RadarChart.prototype.enumerateDataPoint = function (enumeration) {
                    if (!this.radarChartData || !this.radarChartData.series)
                        return;
                    var series = this.radarChartData.series;
                    for (var _i = 0, series_3 = series; _i < series_3.length; _i++) {
                        var serie = series_3[_i];
                        enumeration.pushInstance({
                            objectName: "dataPoint",
                            displayName: serie.name,
                            selector: visuals.ColorHelper.normalizeSelector(serie.identity.getSelector(), false),
                            properties: {
                                fill: { solid: { color: serie.fill } }
                            }
                        });
                    }
                };
                RadarChart.prototype.updateViewport = function () {
                    var legendMargins = this.legend.getMargins(), legendPosition;
                    legendPosition = visuals.LegendPosition[this.legendObjectProperties[visuals.legendProps.position]];
                    switch (legendPosition) {
                        case visuals.LegendPosition.Top:
                        case visuals.LegendPosition.TopCenter:
                        case visuals.LegendPosition.Bottom:
                        case visuals.LegendPosition.BottomCenter:
                            this.viewport.height -= legendMargins.height;
                            break;
                        case visuals.LegendPosition.Left:
                        case visuals.LegendPosition.LeftCenter:
                        case visuals.LegendPosition.Right:
                        case visuals.LegendPosition.RightCenter:
                            this.viewport.width -= legendMargins.width;
                            break;
                    }
                };
                RadarChart.capabilities = {
                    dataRoles: [
                        {
                            displayName: 'Category',
                            name: 'Category',
                            kind: powerbi.VisualDataRoleKind.Grouping,
                        },
                        {
                            displayName: 'Y Axis',
                            name: 'Y',
                            kind: powerbi.VisualDataRoleKind.Measure,
                        },
                    ],
                    dataViewMappings: [{
                            conditions: [{ 'Category': { min: 1, max: 1 } }],
                            categorical: {
                                categories: {
                                    for: { in: 'Category' },
                                    dataReductionAlgorithm: { top: {} }
                                },
                                values: {
                                    select: [{ bind: { to: 'Y' } }]
                                }
                            }
                        }],
                    objects: {
                        general: {
                            displayName: powerbi.data.createDisplayNameGetter('Visual_General'),
                            properties: {
                                formatString: {
                                    type: { formatting: { formatString: true } },
                                },
                            },
                        },
                        legend: {
                            displayName: powerbi.data.createDisplayNameGetter('Visual_Legend'),
                            description: powerbi.data.createDisplayNameGetter('Visual_LegendDescription'),
                            properties: {
                                show: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_Show'),
                                    type: { bool: true }
                                },
                                position: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_LegendPosition'),
                                    description: powerbi.data.createDisplayNameGetter('Visual_LegendPositionDescription'),
                                    type: { enumeration: visuals.legendPosition.type }
                                },
                                showTitle: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_LegendShowTitle'),
                                    description: powerbi.data.createDisplayNameGetter('Visual_LegendShowTitleDescription'),
                                    type: { bool: true }
                                },
                                titleText: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_LegendName'),
                                    description: powerbi.data.createDisplayNameGetter('Visual_LegendNameDescription'),
                                    type: { text: true },
                                    suppressFormatPainterCopy: true
                                },
                                labelColor: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_LegendTitleColor'),
                                    type: { fill: { solid: { color: true } } }
                                },
                                fontSize: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_TextSize'),
                                    type: { formatting: { fontSize: true } }
                                }
                            }
                        },
                        dataPoint: {
                            displayName: powerbi.data.createDisplayNameGetter('Visual_DataPoint'),
                            description: powerbi.data.createDisplayNameGetter('Visual_DataPointDescription'),
                            properties: {
                                fill: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_Fill'),
                                    type: { fill: { solid: { color: true } } }
                                }
                            }
                        },
                        labels: {
                            displayName: powerbi.data.createDisplayNameGetter('Visual_DataPointsLabels'),
                            description: powerbi.data.createDisplayNameGetter('Visual_DataPointsLabelsDescription'),
                            properties: {
                                show: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_Show'),
                                    type: { bool: true }
                                },
                                color: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_LabelsFill'),
                                    description: powerbi.data.createDisplayNameGetter('Visual_LabelsFillDescription'),
                                    type: { fill: { solid: { color: true } } }
                                },
                                labelDisplayUnits: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_DisplayUnits'),
                                    description: powerbi.data.createDisplayNameGetter('Visual_DisplayUnitsDescription'),
                                    type: { formatting: { labelDisplayUnits: true } },
                                    suppressFormatPainterCopy: true,
                                },
                                labelPrecision: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_Precision'),
                                    description: powerbi.data.createDisplayNameGetter('Visual_PrecisionDescription'),
                                    placeHolderText: powerbi.data.createDisplayNameGetter('Visual_Precision_Auto'),
                                    type: { numeric: true },
                                    suppressFormatPainterCopy: true,
                                },
                                fontSize: {
                                    displayName: powerbi.data.createDisplayNameGetter('Visual_TextSize'),
                                    type: { formatting: { fontSize: true } }
                                },
                            }
                        }
                    }
                };
                /** Note: Public for testability */
                RadarChart.formatStringProp = {
                    objectName: 'general',
                    propertyName: 'formatString',
                };
                RadarChart.Properties = {
                    legend: {
                        show: { objectName: 'legend', propertyName: 'show' }
                    },
                    dataPoint: {
                        fill: { objectName: 'dataPoint', propertyName: 'fill' }
                    },
                    labels: {
                        show: { objectName: 'labels', propertyName: 'show' },
                        color: { objectName: 'labels', propertyName: 'color' },
                        displayUnits: { objectName: 'labels', propertyName: 'labelDisplayUnits' },
                        precision: { objectName: 'labels', propertyName: 'labelPrecision' },
                        fontSize: { objectName: 'labels', propertyName: 'fontSize' },
                    }
                };
                RadarChart.VisualClassName = 'radarChart';
                RadarChart.Segments = CreateClassAndSelector('segments');
                RadarChart.SegmentNode = CreateClassAndSelector('segmentNode');
                RadarChart.Axis = CreateClassAndSelector('axis');
                RadarChart.AxisNode = CreateClassAndSelector('axisNode');
                RadarChart.AxisLabel = CreateClassAndSelector('axisLabel');
                RadarChart.Chart = CreateClassAndSelector('chart');
                RadarChart.ChartNode = CreateClassAndSelector('chartNode');
                RadarChart.ChartPolygon = CreateClassAndSelector('chartPolygon');
                RadarChart.ChartDot = CreateClassAndSelector('chartDot');
                RadarChart.DefaultMargin = {
                    top: 50,
                    bottom: 50,
                    right: 100,
                    left: 100
                };
                RadarChart.SegmentLevels = 6;
                RadarChart.SegmentFactor = 1;
                RadarChart.Radians = 2 * Math.PI;
                RadarChart.Scale = 1;
                RadarChart.AreaFillOpacity = 1;
                RadarChart.DimmedAreaFillOpacity = 0.4;
                return RadarChart;
            }());
            RadarChart1446119667547.RadarChart = RadarChart;
        })(RadarChart1446119667547 = visuals.RadarChart1446119667547 || (visuals.RadarChart1446119667547 = {}));
    })(visuals = powerbi.visuals || (powerbi.visuals = {}));
})(powerbi || (powerbi = {}));
var powerbi;
(function (powerbi) {
    var visuals;
    (function (visuals) {
        var plugins;
        (function (plugins) {
            plugins.RadarChart1446119667547 = {
                name: 'RadarChart1446119667547',
                class: 'RadarChart1446119667547',
                capabilities: powerbi.visuals.RadarChart1446119667547.RadarChart.capabilities,
                custom: true,
                create: function () { return new powerbi.visuals.RadarChart1446119667547.RadarChart(); }
            };
        })(plugins = visuals.plugins || (visuals.plugins = {}));
    })(visuals = powerbi.visuals || (powerbi.visuals = {}));
})(powerbi || (powerbi = {}));
